Create database Sales_data;
Use Sales_data;
Create table Western_sale (
Segment Varchar(50),
Country varchar (50),
Product Varchar (50),
Discount_band Varchar (50),
Unit_sold Float,
Manufacturing_Price Float,
Sale_price Float,
Gross_sales Float,
Discounts Float,
Sales Float,
COGS Float,
Profit Float,
Dates Date,
Month_Number INT,
Month_Name Varchar(50),
Years int
);

SELECT * FROM Western_sale;


-- Find total units sold per country:

SELECT 
    country, SUM(unit_sold) AS Total_Unit_sold
FROM
    Western_sale
GROUP BY country;


-- Find total gross sales per product:
SELECT 
    Product, SUM(Gross_sales) AS Total_Gross_Sales
FROM
    Western_sale
GROUP BY Product;

-- Calculate the total profit for each segment:

SELECT 
    Segment, SUM(Profit) AS Total_Profit
FROM
    western_sale
GROUP BY Segment ;


-- Find the total Cost of Goods Sold (COGS) for each month:
SELECT 
    Month_Name, SUM(COGS) AS Total_Cost_Of_Goods
FROM
    western_sale
GROUP BY Month_Name

